﻿using System.Collections.Generic;

namespace DealOrNoDeal.Model
{
    /// <summary>
    ///     Creates a Banker object that will be able to calculate an offer
    /// </summary>
    public class Banker
    {
        #region Data members

        private readonly IList<int> allOffers;

        #endregion

        #region Properties

        /// <summary>
        ///     Keeps Track of the minimum offer
        /// </summary>
        public int MinOffer { get; private set; }

        /// <summary>
        ///     Keeps Track of the maximum offer
        /// </summary>
        public int MaxOffer { get; private set; }

        /// <summary>
        ///     Keeps Track of the average offer
        /// </summary>
        public int AverageOffer { get; private set; }

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="Banker" /> class.
        /// </summary>
        public Banker()
        {
            this.MinOffer = int.MaxValue;
            this.MaxOffer = int.MinValue;
            this.AverageOffer = 0;
            this.allOffers = new List<int>();
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Gets the offer.
        /// </summary>
        /// <param name="dollarAmountsLeft">The dollar amounts left.</param>
        /// <param name="casesInNextRound">The cases in next round.</param>
        /// <returns> The Bankers calculated offer</returns>
        public int GetOffer(List<int> dollarAmountsLeft, int casesInNextRound)
        {
            var sum = 0;
            foreach (var amount in dollarAmountsLeft)
            {
                sum += amount;
            }

            var divideNextRoundOfCases = sum / casesInNextRound;
            var offer = divideNextRoundOfCases / dollarAmountsLeft.Count;
            offer = (offer + 50) / 100 * 100;
            this.updateOfferAmounts(offer);
            return offer;
        }

        private void updateOfferAmounts(int offer)
        {
            if (offer > this.MaxOffer)
            {
                this.MaxOffer = offer;
            }

            if (offer < this.MinOffer)
            {
                this.MinOffer = offer;
            }

            this.calculateAverageOffer(offer);
        }

        private void calculateAverageOffer(int offer)
        {
            this.allOffers.Add(offer);
            var sumOffers = 0;
            foreach (var current in this.allOffers)
            {
                sumOffers += current;
            }

            this.AverageOffer = sumOffers / this.allOffers.Count;
            this.AverageOffer = (this.AverageOffer + 50) / 100 * 100;
        }

        #endregion
    }
}